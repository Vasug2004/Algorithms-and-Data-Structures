﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_A_B_C
{
    class GraphNode<T>
    {
        private T id; // data stored in the node. can think like the (unique) "label" of the node

        private LinkedList<T> adjList; // adjacent list of the node

        public GraphNode(T id) // constructor
        {
            this.id = id;
            adjList = new LinkedList<T>();
        }

        public T ID // set and get the data stored in the node 
        {
            set { id = value; }
            get { return id; }
        }

        public void AddEdge(GraphNode<T> to) //add edge from this node to the node "to"; it is an unweighted and *directed* graph. 
        {
            adjList.AddLast(to.ID);
        }

        public LinkedList<T> GetAdjList() // return the adjacent list of the node (needed for the visit of the graph)
        {
            return adjList;
        }
    }
}
