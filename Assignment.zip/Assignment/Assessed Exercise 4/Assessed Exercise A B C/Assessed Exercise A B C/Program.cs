﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_A_B_C
{
    class Program
    {
        static void Main(string[] args)
        {
            Graph<string> myGraph = new Graph<string>(); // define a graph with ID of nodes as 'char'

            myGraph.AddNode("Vasu");
            myGraph.AddNode("Dillan");
            myGraph.AddNode("Jai");
            myGraph.AddNode("Eleisha");
            myGraph.AddNode("Celina");
            myGraph.AddNode("Bellis");
            myGraph.AddNode("Scarlett");
            myGraph.AddNode("Trent");
            myGraph.AddNode("Michelle");
            myGraph.AddNode("Rish");


            while (true)
            {
                Console.WriteLine("1. Insert a new individual");
                Console.WriteLine("2. Insert a directed edge between two nodes");
                Console.WriteLine("3. Display the current number of nodes");
                Console.WriteLine("4. Display the current number of edge");
                Console.WriteLine("5. Exit");
                Console.WriteLine("Enter your choice");

                int choice;
                if (int.TryParse(Console.ReadLine(), out choice)) // // Converts the users input from a string into an integer

                switch(choice)
                {
                    case 1:
                        var displayNodes = myGraph.DisplayNodes();
                        Console.WriteLine("Current individuals in the graph: {0}", string.Join(", ", displayNodes));
                        Console.WriteLine("Enter the name of the individual: ");
                        string Name = Console.ReadLine();
                        myGraph.AddNode(Name);
                        Console.WriteLine("{0} added to the graph.", Name);
                        break;

                    case 2:
                        var displaynodes = myGraph.DisplayNodes();
                        Console.WriteLine("Current individuals in the graph: {0}", string.Join(", ", displaynodes));
                        Console.WriteLine("Enter the ID of the first individual: ");
                        string fromName = Console.ReadLine();
                        Console.WriteLine("Enter the ID of the second individual: ");
                        string toName = Console.ReadLine();
                        myGraph.AddEdge(fromName, toName);
                        Console.WriteLine("Edge added between {0} and {1}.", fromName, toName);
                        break;

                    case 3:
                        Console.WriteLine("Current number of individuals in the graph: {0}", myGraph.NumNodesGraph());
                        break;

                    case 4:
                        Console.WriteLine("Current number of edges in the graph: {0}", myGraph.NumEdgesGraph());
                        break;

                        case 5:
                        return; // Exit Method

                    default:
                        Console.WriteLine("Invalid Choice. Try again");
                            break;
                }
                Console.ReadKey();
            }
        }
    }
}
