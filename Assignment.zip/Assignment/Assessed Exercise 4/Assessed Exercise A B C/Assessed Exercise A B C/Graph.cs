﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_A_B_C
{
    class Graph<T> where T : IComparable
    {
        private LinkedList<GraphNode<T>> nodes; // list of graphnodes in the graph (nodes in the graph)
        private int counterEdges; // Counter for the number of edges in the graph

        public Graph() // constructor. set the list of nodes in the graph to be the empty list
        {
            nodes = new LinkedList<GraphNode<T>>();
        }

        public bool IsEmptyGraph() // check if the graph is empty (no node is present)
        {
            //if the number of the elements within nodes is equal to 0, return true;
            //otherwise, return false; 
            return nodes.Count == 0;
        }

        public void AddNode(T id) // add a new node in the graph. use constructor of graphnode
        {
            nodes.AddLast(new GraphNode<T>(id));
        }

        public bool ContainsGraph(GraphNode<T> node) // only returns true if node is present in the graph
        {
            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(node.ID) == 0) // validation to be completed: add a check that node is not null
                {
                    return true;
                }
            }
            return false;
        }

        public GraphNode<T> GetNodeByID(T id)  //returns the node with this id
        {
            foreach (GraphNode<T> n in nodes)
            {
                if (id.CompareTo(n.ID) == 0) return n;
            }
            return null;
        }

        public void AddEdge(T from, T to) //Add a directed edge between the node with id "from" and the node with id “to”
        {
            GraphNode<T> n1 = GetNodeByID(from);
            GraphNode<T> n2 = GetNodeByID(to);

            if (n1 != null && n2 != null)
            {
                n1.AddEdge(n2);
                counterEdges++; // Increment the edge counter
            }
        }

        public bool IsAdjacent(GraphNode<T> from, GraphNode<T> to) // return true if "to" is adjacent to "from"
        {
            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(from.ID) == 0) // Find the node with ID "from" in the graph
                {
                    return n.GetAdjList().Contains(to.ID); //check if "to" is in the adjacency list of "from"
                }
            }
            return false;
        }

        public int NumNodesGraph()  // returns the total number of nodes present in the graph
        {
            return nodes.Count; // once you have that list, you can count (and return) how many elements are in the list             
        }

        public int NumEdgesGraph()  // returns the total number of edges present in the graph
        {
            return counterEdges;
            // easier way: add an int variable (i.e. counteredges) in class Graph which is increased every time an edge is added
        }

        public List<T> DisplayNodes()
        {
            List<T> nodeList = new List<T>();

            foreach (var n in nodes)
            {
                nodeList.Add(n.ID);
            }
            return nodeList;
        }
    }
}
