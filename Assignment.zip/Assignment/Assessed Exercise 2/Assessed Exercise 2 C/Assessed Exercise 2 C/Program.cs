﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_2_C
{
    class Program
    {
        static void Main(string[] args)
        {
            AVLTree<int> myTree = new AVLTree<int>();
        }
    }
}
