﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_2_C
{
    class BinTree<T> where T : IComparable
    {
        protected Node<T> root;
        public BinTree() // creates an empty tree
        {
            root = null;
        }

        public BinTree(Node<T> node) //creates a tree with node as the root
        {
            root = node;
        }

        public void InOrder(ref string buffer)
        {
            inOrder(root, ref buffer);
        }

        public void PreOrder(ref string buffer)
        {
            preOrder(root, ref buffer);
        }

        public void PostOrder(ref string buffer)
        {
            postOrder(root, ref buffer);
        }

        public int Height()
        {
            return height(root);
        }
        public int Count()
        {
            return CountNodes(root);
        }

        public Boolean Contains(T item)
        {
            return ContainsItem(root, item);
        }

        private void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                inOrder(tree.Left, ref buffer);
                buffer += tree.Data.ToString() + ", ";
                inOrder(tree.Right, ref buffer);
            }
        }

        private void preOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                buffer += tree.Data.ToString() + ", ";
                preOrder(tree.Left, ref buffer);
                preOrder(tree.Right, ref buffer);
            }
        }

        private void postOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                postOrder(tree.Left, ref buffer);
                postOrder(tree.Right, ref buffer);
                buffer += tree.Data.ToString() + ", ";
            }
        }

        protected int height(Node<T> node)
        {
            if (node == null)
            {
                return 0; // Height of an empty tree is 0
            }
            else
            {
                int leftHeight = height(node.Left); // height of left & right subtree
                int rightHeight = height(node.Right);

                return Max(leftHeight, rightHeight) + 1; // return maximum height of the left or right subtree, plus 1 for the current level
            }
        }

        private int Max(int x, int y) // Max func
        {
            return x > y ? x : y;
        }

        private int CountNodes(Node<T> node)
        {
            if (node == null)
            {
                return 0; // number of nodes in an empty tree is 0
            }
            else
            {
                return 1 + CountNodes(node.Left) + CountNodes(node.Right); // Count the current node and recursively count nodes in left and right subtree 
            }
        }

        private Boolean ContainsItem(Node<T> node, T item)
        {
            if (node == null)
            {
                return false; // item is not found in an empty tree
            }
            else
            {
                int compareResult = item.CompareTo(node.Data);

                if (compareResult == 0)
                {
                    return true; // item found at the current node
                }
                else if (compareResult < 0)
                {
                    return ContainsItem(node.Left, item); // recursively search in the left subtree
                }
                else
                {
                    return ContainsItem(node.Right, item); // recursively search in the right subtree
                }
            }
        }
    }
}
