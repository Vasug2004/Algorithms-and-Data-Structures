﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_2_A_B
{
    class BinTree<T> where T : IComparable
    {
        protected Node<T> root; // protected - allows inheriting class, access to root
        public BinTree() // creates an empty tree
        {
            root = null;
        }

        public BinTree(Node<T> node) //creates a tree with node as the root
        {
            root = node;
        }

        public void InOrder(ref string buffer) // In Order Traversal method
        {

            inOrder(root, ref buffer);
        }

        public void PreOrder(ref string buffer) // PreOrder Traversal method
        {

            preOrder(root, ref buffer);
        }

        public void PostOrder(ref string buffer) // PostOrder Traversal method
        {

            postOrder(root, ref buffer);
        }

        public int Height() // Height of tree method
        {
            return TreeHeight(root);
        }

        public int Count() // Count number of nodes method
        {
            return CountNodes(root);
        }

        private void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null) // if tree is not empty
            {
                inOrder(tree.Left, ref buffer); // InOrder traverse left sub tree
                buffer += tree.Data.ToString() + ", "; // display value in node
                inOrder(tree.Right, ref buffer); // InOrder traverse right sub-tree
            }
        }

        private void preOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null) // if tree is not empty
            {
                buffer += tree.Data.ToString() + ", "; // display the value in node
                preOrder(tree.Left, ref buffer); // Preorder traverse left sub tree
                preOrder(tree.Right, ref buffer); // preorder traverse right sub tree
            }
        }

        private void postOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null) // if tree is not empty
            {
                postOrder(tree.Left, ref buffer); // post-order traverse left sub tree
                postOrder(tree.Right, ref buffer); // post order traverse right sub tree
                buffer += tree.Data.ToString() + ", "; // display value in node
            }
        }

        private int TreeHeight(Node<T> node)
        {
            if (node == null)
            {
                return 0; // Height of an empty tree is 0
            }
            else
            {
                int leftHeight = TreeHeight(node.Left); // height of left & right subtree
                int rightHeight = TreeHeight(node.Right);

                return Max(leftHeight, rightHeight) + 1; // return maximum height of the left or right subtree, plus 1 for the current level
            }
        }

        private int Max(int x, int y) // Max func
        {
            return x > y ? x : y;
        }

        private int CountNodes(Node<T> node)
        {
            if (node == null)
            {
                return 0; // number of nodes in an empty tree is 0
            }
            else
            {
                return 1 + CountNodes(node.Left) + CountNodes(node.Right); // Count the current node and recursively count nodes in left and right subtree 
            }
        }
    }
}
