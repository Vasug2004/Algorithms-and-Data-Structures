﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_2_A_B
{
    class Program
    {
        static void Main(string[] args)
        {
            BSTree<string> myBSTree = new BSTree<string>(); // Creates a BS Tree 

            myBSTree.InsertItem("Hello");
            myBSTree.InsertItem("Good");
            myBSTree.InsertItem("Football");
            myBSTree.InsertItem("Liverpool");
            myBSTree.InsertItem("Preston");

            while (true)
            {
                Console.WriteLine("1. Insert a word into the Binary Search Tree"); // Allows the user to insert a word into the tree
                Console.WriteLine("2. In-order traversal"); // Allows the user to display the tree in Inorder traversal
                Console.WriteLine("3. Pre-order traversal"); // Allows the user to display the tree in PreOrder traversal
                Console.WriteLine("4. Post-order traversal"); // Allows the user to display the tree in PostOrder traversal
                Console.WriteLine("5. Display the height of the tree"); // Allows the user to display the height of the tree
                Console.WriteLine("6. Count number of nodes in the Binary Search Tree"); // Allows the user to count the number of nodes in the tree
                Console.WriteLine("7. Check if word is present and remove it"); // Allows the user to check if the word is present and then remove it
                Console.WriteLine("8. Exit"); // Allows the user to exit the console application
                Console.WriteLine("Enter your choice");

                int choice;
                if (int.TryParse(Console.ReadLine(), out choice)) // Converts the users input from a string into an integer

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter a word to insert into the tree: ");
                        string InsertWord = Console.ReadLine(); // Stores user's input 
                        myBSTree.InsertItem(InsertWord); // Display user's input 
                        break;

                    case 2:
                        string inOrderbuffer = "";
                        myBSTree.InOrder(ref inOrderbuffer);
                        Console.WriteLine("In-order Traversal: " + inOrderbuffer); // perform the in order traversal and display content of the tree
                        break;

                    case 3:
                        string preOrderbuffer = "";
                        myBSTree.PreOrder(ref preOrderbuffer);
                        Console.WriteLine("Pre-order Traversal: " + preOrderbuffer); // perform the pre order traversal and display the content of the tree
                        break;

                    case 4:
                        string postOrderbuffer = "";
                        myBSTree.PostOrder(ref postOrderbuffer);
                        Console.WriteLine("Post-order Traversal: " + postOrderbuffer); // perform the post order traversal and display the content of the tree
                            break;

                    case 5:
                        Console.WriteLine("Tree Height is: " + myBSTree.Height()); // Display tree height
                            break;

                    case 6:
                        Console.WriteLine("Total number of Nodes: " + myBSTree.Count()); // Display number of nodes in tree
                        break;

                    case 7:
                        Console.WriteLine("Enter a word to check and remove: ");
                        string wordCheck = Console.ReadLine();

                        if (myBSTree.Contains(wordCheck)) // Check user's word is present
                        {
                            Console.WriteLine(wordCheck + " is present in the Binary Search Tree");
                            myBSTree.RemoveItem(wordCheck); // Remove's user's word from tree
                            Console.WriteLine(wordCheck + " has been removed from the tree");
                            string inOrderBuffer = "";
                            myBSTree.InOrder(ref inOrderBuffer); // Outputs the tree
                            Console.WriteLine("Updated In-order Traversal Tree: " + inOrderBuffer);
                        }
                        else
                        {
                            Console.WriteLine(wordCheck + " is not present in the Binary Search Tree"); // Outputs user's word is not present
                        }
                        break;

                    case 8:
                        return; // Exit Method
                 
                    default:
                        Console.WriteLine("Invalid Choice. Try again");
                        break;
                }
                Console.ReadKey();
            }
        }
    }
}
