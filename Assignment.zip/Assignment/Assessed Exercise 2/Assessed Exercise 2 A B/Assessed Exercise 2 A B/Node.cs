﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_2_A_B
{
    class Node<T> where T : IComparable
    {
        private T data;
        public Node<T> Left, Right;

        public Node(T item) // constructor
        {
            data = item;
            Left = null;
            Right = null;
        }

        public T Data // poperty for data set & get
        {
            set { data = value; }
            get { return data; }
        }
    }
}
