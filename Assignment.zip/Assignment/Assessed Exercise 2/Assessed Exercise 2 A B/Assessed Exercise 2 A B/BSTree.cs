﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_2_A_B
{
    class BSTree<T> : BinTree<T> where T:IComparable
    {
        public BSTree()
        {
            root = null;
        }

        public void InsertItem(T item) // Insert item into tree method
        {
            insertItem(item, ref root);
        }

        public Boolean Contains(T item) // Check if item is present in the tree method
        {
            return ContainsItem(root, item);
        }

        public void RemoveItem(T item) // Remove the item from the tree
        {
            removeItem(item, ref root);
        }

        private void insertItem(T item, ref Node<T> tree)
        {
            if (tree == null)
                tree = new Node<T>(item);

            else if (item.CompareTo(tree.Data) < 0)
                insertItem(item, ref tree.Left);

            else if (item.CompareTo(tree.Data) > 0)
                insertItem(item, ref tree.Right);
        }

        private Boolean ContainsItem(Node<T> node, T item)
        {
            if (node == null)
            {
                return false; // item is not found in an empty tree
            }
            else
            {
                if (item.CompareTo(node.Data) == 0)
                {
                    return true; // item found at the current node
                }
                else if (item.CompareTo(node.Data) < 0)
                {
                    return ContainsItem(node.Left, item); // recursively search in the left subtree
                }
                else
                {
                    return ContainsItem(node.Right, item); // recursively search in the right subtree
                }
            }
        }

        private void removeItem(T item, ref Node<T> tree)
        {
            if (tree == null)
            {
                return; // if the tree is empty, do nothing
            }

            else if (item.CompareTo(tree.Data) < 0) // Item is smaller than the current node, search in the left subtree
            {
                removeItem(item, ref tree.Left);
            }

            else if (item.CompareTo(tree.Data) > 0) // Item is larger than the current node, search in the right subtree
            {
                removeItem(item, ref tree.Right);
            }

            else
            {
                if (tree.Left == null && tree.Right != null) // Case 1: Node with only a right child
                {
                    tree = tree.Right;
                }

                else if (tree.Left != null && tree.Right == null) // Case 2: Node with only a left child
                {
                    tree = tree.Left;
                }

                else if (tree.Left != null && tree.Right != null) // Case 3: Node with both left and right children
                {
                    T newRoot = LeastItem(tree.Right);
                    tree.Data = newRoot;
                    removeItem(newRoot, ref tree.Right);
                }

                else
                {
                    tree = null; // Case 4: Node is a leaf (no children)
                }
            }
        }

        private T LeastItem(Node<T> tree) // Find and return thee left most item
        {
            if (tree.Left == null)
            {
                return tree.Data;
            }
            else
            {
                return LeastItem(tree.Left);
            }
        }
    }
}
