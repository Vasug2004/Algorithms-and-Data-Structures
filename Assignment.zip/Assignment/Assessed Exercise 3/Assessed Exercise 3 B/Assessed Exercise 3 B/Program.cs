﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Assessed_Exercise_3_B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create an array of integer (randomly chosen) to test the selection sort
            int Min = 0; // min number 
            int Max = 200; // max number
            int[] Num = new int[10]; // constructor to store 10 integers
            Random randNum = new Random(); // Random generator to generate 10 random numbers between 0 to 200.
            for (int i = 0; i < Num.Length; i++) // Loop to generate a random number
            {
                Num[i] = randNum.Next(Min, Max);
            }
            
                Console.WriteLine("Original array of integers: "); // Display original array of numbers
            for(int i = 0; i < Num.Length; i++)
            {
                Console.WriteLine(Num[i].ToString());
            }

            SelectSortGen(Num);

            Console.WriteLine("\nSorted array of integers: "); // Display sorted array of numbers
            for (int i = 0; i < Num.Length; i++)
            {
                Console.WriteLine(Num[i].ToString());
            }

            string[] title = { "Writing Solid Code", "object First", "Programming Gems", "Head First Java", "The C Programming Language", "Mythical Man Month", "The Art of Programming", "Coding Complete", "Design Patterns", "ZZ" }; // List of titles
            string[] authors = { "Maguire", "Kolling", "Bentley", "Sierra", "Richie", "Brooks", "Knuth", "McConnal", "Gamma", "Weiss" }; // List of authors
            int[] pub_year = { 1976, 1983, 1947, 1977, 2004, 2007, 2002, 2020, 2024, 2012 }; // List of years
            Book[] library = new Book[10]; // constructor to store 10 books

            // create an array of books
            for (int i = 0; i < library.Length; i++) // loop to display a book, title, publication year.
            {
                library[i] = new Book(pub_year[i], authors[i], title[i]);
            }

            Console.WriteLine("\nOriginal array of Books: "); // Display original array of books
            for (int i = 0; i < library.Length; i++)
            {
                Console.WriteLine(library[i].ToString());
            }

            SelectSortGen(library);

            Console.WriteLine("\nSorted array of Book: "); // Display sorted array of books
            for (int i = 0; i < library.Length;i++)
            {
                Console.WriteLine(library[i].ToString());
            }

            Console.ReadLine();
        }

        static public void SelectSortGen<T>(T[] a) where T : IComparable<T> // Selection Sort Method
        {
            for (int i = 0; i < a.Length - 1; i++)
            {
                int smallest = i;
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[j].CompareTo(a[smallest]) < 0)
                        smallest = j;
                }
                swap(ref a[i], ref a[smallest]);
            }
        }

        static void swap<T>(ref T x, ref T y) // Method to swap
        {
            T temp = x;
            x = y;
            y = temp;
        }
    }
}
