﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_3_B
{
    class Book : IComparable<Book>
    {
        private int pub_year;
        private string author;
        private string title;

        public Book(int pub_year, string author, string title) // Constructor to store 
        {
            Pub_Year = pub_year;
            Author = author;
            Title = title;
        }

        public int Pub_Year
        {
            get { return pub_year; }
            set { pub_year = value; }
        }

        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public int CompareTo(Book other)
        {
            //Book other = (Book)obj;
            return Pub_Year.CompareTo(other.Pub_Year);
        }

        public override string ToString()
        {
            return string.Format("Publication Year is {0}, title is {1}, author is {2}.", Pub_Year, Title, Author);
        }
    }
}
