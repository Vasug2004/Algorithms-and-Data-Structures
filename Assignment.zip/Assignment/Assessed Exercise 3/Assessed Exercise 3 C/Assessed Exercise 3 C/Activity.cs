﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_3_C
{
    class Activity : IComparable<Activity>
    {
        private int id;
        private double start_time;
        private double finish_time;

        public Activity(int id, double start_time, double finish_time)
        {
            ID = id;
            Start_Time = start_time;
            Finish_Time = finish_time;
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public double Start_Time
        {
            get { return start_time; }
            set { start_time = value; }
        }

        public double Finish_Time
        {
            get { return finish_time; }
            set { finish_time = value; }
        }

        public int CompareTo(Activity other)
        {
            return Finish_Time.CompareTo(other.Finish_Time);
        }
    }
}
