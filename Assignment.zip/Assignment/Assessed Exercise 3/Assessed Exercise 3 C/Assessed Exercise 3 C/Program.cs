﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_3_C
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Activity> activities = new List<Activity>();

            while (true)
            {
                Console.WriteLine("1. Insert new activity");
                Console.WriteLine("2. Display largest possible set of requests");
                Console.WriteLine("3. Exit");
                Console.WriteLine("Enter");
            }

            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
            
            switch(choice)
                {
                    case 1:
                        break;

                    case 2:
                        break;

                    case 3:
                        return; // Exit Method

                    default:
                        Console.WriteLine("Invalid Choice. Try again");
                }
            Console.ReadKey();
        }
    }
}
