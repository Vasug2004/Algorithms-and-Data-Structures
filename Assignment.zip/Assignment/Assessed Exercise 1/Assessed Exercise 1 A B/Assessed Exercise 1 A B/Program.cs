﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_1_A_B
{
    class Program
    {
        static void Main(string[] args)
        {
            IntStack mystack = new IntStack(10); // Create a stack to store integers
            Random randgen = new Random(); // Random Generator to store random numbers

            for (int i = 0; i < 8;i++) // For loop to generate 8 numbers
            {
                int RandomNumber = randgen.Next(100); // Choose any random numbers between 0 - 100
                mystack.Push(RandomNumber);
            }

            while (true)
            {
                Console.WriteLine("1. Add Integer to Stack"); // Allows user to choose to add an integer to the stack
                Console.WriteLine("2. Remove Integer from Stack"); // Allows user to remove an integer to the stack
                Console.WriteLine("3. Display Stack Integers"); // Allows user to see the stack of integers
                Console.WriteLine("4. Number of Items in the Stack"); // Allows user to see the quantity of integers in the stack
                Console.WriteLine("5. Sort the Integers in the Stack"); // Allows user to see the integers in a sorted stack
                Console.WriteLine("6. Exit"); // Allows user to exit the console application
                Console.WriteLine("Enter your choice"); 
                
                int choice = Convert.ToInt32(Console.ReadLine()); //Allows user to choose between options 1 - 5

                switch (choice) // Used to switch instead of multiple if statements for simplicity and vary code for user experience
                {
                    case 1:
                        Console.WriteLine("Enter an integer to add to the stack: ");
                        int addNum;                                                      // addNum to store the user's input
                        if (int.TryParse(Console.ReadLine(), out addNum)) // Converts Users input from a string to an integer
                        {
                            mystack.Push(addNum); // Push Method
                            Console.WriteLine($"{addNum} is added to the stack."); // Displays the user's input in a string
                        }

                        else
                        {
                            Console.WriteLine("Invalid input. Please enter a valid integer.");
                        }
                        break;

                    case 2:
                        if (!mystack.IsEmpty()) // Pop Method
                        {
                            int removedInt = mystack.Pop();
                            Console.WriteLine($"Removed {removedInt} from the stack.");
                        }

                        else
                        {
                            Console.WriteLine("Stack is empty. Cannot remove this integer.");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Stack Contents:"); // Display Stack Method
                        Console.WriteLine(mystack.Print());
                        break;

                    case 4:
                        Console.WriteLine($"Number of items in the stack: " + mystack.Count()); // Display Number of Items Method
                        break;

                    case 5:
                        Console.WriteLine("Original Stack: " + mystack.Print()); // Display the original stack
                        mystack.SortAscending(); 
                        Console.WriteLine("Sorted stack in ascending order: " + mystack.Print()); // Display the stack after sorting in ascending order
                        break;

                    case 6:
                        return; // Exit Method

                    default:
                        Console.WriteLine("Invalid choice. Try again"); 
                        break;
                }

            Console.ReadKey();
            }
        }
    }
}
