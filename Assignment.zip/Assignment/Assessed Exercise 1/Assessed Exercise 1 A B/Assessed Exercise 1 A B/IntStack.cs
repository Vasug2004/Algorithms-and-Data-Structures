﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_1_A_B
{
    class IntStack
    {
        private int maxsize = 10;
        private int top = 0;
        private int[] myarray;

        public IntStack(int size) // IntStack constructor
        {
           maxsize = size;
           myarray = new int[maxsize];
        }
        public void Push(int value) // Push Method
        {
            myarray[top++] = value;
        }

        public int Pop() // Pop Method
        {
            if (top > 0)
            {
                return myarray[--top];
            }
            else
            {
                Console.WriteLine("Stack is empty.");
                return -1;
            }
        }
        public int Peek() // Peek Method
        {
            return myarray[top - 1];
        }

        public bool IsEmpty() // If stack is empty
        {
            return top == 0;
        }

        public bool IsFull() // If stack is full
        {
            return top == maxsize;
        }

        public int Count() // Display Number of Items Method
        {
            return top;
        }

        public void SortAscending() // Sorting Integers Method
        {
            /*StringBuilder output = new StringBuilder();
            for (int i = top - 1; i >= 0; i--)
                output.Append(myarray[i] + " ");
            return output.ToString();*/
            Array.Sort(myarray, 0, top); // Sorts the stack in Ascending order
        }

        public string Print() // Stack Contents Method
        {
            StringBuilder output = new StringBuilder();
               // for (int i = top - 1; i >= 0; i--)
               for (int i = 0; i < top; i++)
                output.Append(myarray[i] + " ");
            return output.ToString();
        }
    }
}
