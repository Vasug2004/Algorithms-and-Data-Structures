﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_1_C
{
    class Book : IComparable
    {
        private string title;
        private string author;
        private string isbn;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        public string ISBN
        {
            get { return isbn; }
            set { isbn = value; }
        }

        public Book(string title, string author, string isbn)
        {
            this.title = title;
            this.author = author;
            this.isbn = isbn;
        }

        public int CompareTo(Object obj)
        {
            Book other = (Book)obj;
            return isbn.CompareTo(other.isbn);
        }

        public override string ToString()
        {
            return $"{Title} by {Author} (ISBN: {ISBN})";
        }

    }
}
