﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Exercise_1_C
{
    class LinkGen<Book>
    {
        private Book data;
        private LinkGen<Book> next;

        public LinkGen(Book item) //Constructor with an item
        {
            Data = item;
            Next = null;
        }

        public LinkGen<Book> Next
        {
            set { this.next = value; }
            get { return this.next; }
        }

        public Book Data
        {
            set { this.data = value; }
            get { return this.data; }
        }

    }
}
